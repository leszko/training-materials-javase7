package com.luxoft.jva007.exercise07.task2;

public class GcTest {
    private int[] bigArray = new int[10000];

    public static void main(String[] args) {
        int n = 10;

        for (int i = 0; i < n; i++) {
            GcTest gcTest = new GcTest();
        }
    }

    @Override
    protected void finalize() {
        System.out.println("Finalize!");
    }
}
